import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    container: {
      center: true,
      padding: "1.5rem",
      screens: { "2xl": "1280px" },
    },
    extend: {
      colors: {
        void: "#08080C",
        surface: "#0F0F16",
        surface2: "#15151F",
        line: "rgba(255,255,255,0.08)",
        signal: {
          DEFAULT: "#5B4CFF",
          soft: "#8B7CFF",
          dim: "#3A2FA0",
        },
        ember: {
          DEFAULT: "#FF8A3D",
          soft: "#FFB073",
        },
        ink: {
          DEFAULT: "#F2F2F7",
          muted: "#9797A8",
          faint: "#5C5C6B",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "grid-fade":
          "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(91,76,255,0.25), transparent)",
        "noise": "url('/noise.png')",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-glow": {
          "0%,100%": { opacity: "0.5" },
          "50%": { opacity: "1" },
        },
        "drift": {
          "0%,100%": { transform: "translate(0,0)" },
          "50%": { transform: "translate(6px,-8px)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.16,1,0.3,1) both",
        "pulse-glow": "pulse-glow 3.5s ease-in-out infinite",
        "drift": "drift 8s ease-in-out infinite",
      },
      backdropBlur: {
        xs: "2px",
      },
    },
  },
  plugins: [],
};

export default config;
