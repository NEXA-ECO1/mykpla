# MYK Platform — v1.0

The digital home of **Mohammad Yasin Karami** — AI Engineer, Python Developer, Entrepreneur.

Built with Next.js 14 (App Router), TypeScript, Tailwind CSS, Framer Motion, and Prisma (SQLite).

## Getting started

```bash
npm install
cp .env.example .env
npx prisma migrate dev --name init
npm run dev
```

Visit `http://localhost:3000` — you'll be redirected to `/en` (or `/fa`, based on your browser's
`Accept-Language` header).

## Project structure

```
src/
  app/
    [locale]/         # localized routes: /, /about, /contact
    api/contact/       # REST endpoint (mirrors the contact server action)
    sitemap.ts          # dynamic, locale-aware sitemap.xml
    robots.ts
  components/
    ui/                # design-system primitives (button, input, glass-card...)
    layout/             # navbar, footer, theme + locale switching
    home/, about/, contact/   # page-specific sections
  features/
    contact/            # zod schema + server action (business logic)
  database/
    repositories/         # the ONLY layer that talks to Prisma
  lib/
    i18n/                # locale config + dictionary loader
    prisma.ts, metadata.ts, utils.ts
  locales/
    en/, fa/               # translation JSON, one file per namespace
prisma/
  schema.prisma           # SQLite now; swap the datasource to migrate to Postgres
```

## Adding a new language

1. Add the code to `locales` in `src/lib/i18n/config.ts` and its direction/label to `localeMeta`.
2. Duplicate `src/locales/en/*.json` into `src/locales/<code>/*.json` and translate.

Routing, RTL/LTR, and the language switcher all pick it up automatically — no other code changes.

## Migrating the database to Postgres later

1. In `prisma/schema.prisma`, change `provider = "sqlite"` to `provider = "postgresql"`.
2. Point `DATABASE_URL` at your Postgres instance.
3. Run `npx prisma migrate dev`.

No application code changes — everything goes through `src/database/repositories/`.

## Deploying to Vercel

1. Push this repo to GitHub.
2. Import it in Vercel.
3. Add the environment variables from `.env.example` (for a persistent database in production,
   use Vercel Postgres, Turso, or another hosted SQLite/Postgres provider — the local SQLite file
   won't persist across serverless deploys).
4. Deploy.

## Roadmap (not in v1)

Projects, Articles, Courses, Books, Events, AI Services, CMS, Admin Panel, AI Agents, public APIs.
The architecture (feature folders, repository pattern, i18n namespaces) is designed so these can be
added incrementally without rewriting the foundation.
