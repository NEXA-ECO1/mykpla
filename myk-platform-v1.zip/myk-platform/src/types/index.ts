import type { Locale } from "@/lib/i18n/config";

export type PageParams = {
  params: { locale: Locale };
};

export interface NavLink {
  href: string;
  label: string;
}

export interface SkillItem {
  name: string;
  detail: string;
}

export interface SkillCategory {
  label: string;
  items: string[];
}

export type ContactFormState = {
  status: "idle" | "success" | "error";
  message?: string;
  fieldErrors?: Partial<Record<"name" | "email" | "subject" | "message", string>>;
};
