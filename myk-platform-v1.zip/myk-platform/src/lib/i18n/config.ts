/**
 * Central i18n configuration.
 *
 * Adding a new language later is a 3-step, no-rewrite process:
 *   1. Add its code to `locales` and metadata to `localeMeta`
 *   2. Add a `src/locales/<code>/*.json` folder with the same keys as `en`
 *   3. Done — routing, direction, and the switcher all pick it up automatically
 */
export const locales = ["en", "fa"] as const;
export type Locale = (typeof locales)[number];

export const defaultLocale: Locale = "en";

export const localeMeta: Record<Locale, { label: string; nativeLabel: string; dir: "ltr" | "rtl" }> = {
  en: { label: "English", nativeLabel: "English", dir: "ltr" },
  fa: { label: "Persian", nativeLabel: "فارسی", dir: "rtl" },
};

export function isLocale(value: string): value is Locale {
  return (locales as readonly string[]).includes(value);
}

export function getDirection(locale: Locale): "ltr" | "rtl" {
  return localeMeta[locale].dir;
}
