import "server-only";
import type { Locale } from "./config";

// Each namespace maps 1:1 to a JSON file under src/locales/<locale>/.
// Add a namespace here once, and every locale folder picks it up.
const loaders = {
  common: (locale: Locale) => import(`@/locales/${locale}/common.json`).then((m) => m.default),
  home: (locale: Locale) => import(`@/locales/${locale}/home.json`).then((m) => m.default),
  about: (locale: Locale) => import(`@/locales/${locale}/about.json`).then((m) => m.default),
  contact: (locale: Locale) => import(`@/locales/${locale}/contact.json`).then((m) => m.default),
};

export type Dictionary = {
  common: typeof import("@/locales/en/common.json");
  home: typeof import("@/locales/en/home.json");
  about: typeof import("@/locales/en/about.json");
  contact: typeof import("@/locales/en/contact.json");
};

export async function getDictionary(locale: Locale): Promise<Dictionary> {
  const [common, home, about, contact] = await Promise.all([
    loaders.common(locale),
    loaders.home(locale),
    loaders.about(locale),
    loaders.contact(locale),
  ]);
  return { common, home, about, contact } as Dictionary;
}
