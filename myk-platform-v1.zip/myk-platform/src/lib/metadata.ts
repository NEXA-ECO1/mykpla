import type { Metadata } from "next";
import type { Locale } from "@/lib/i18n/config";
import { locales } from "@/lib/i18n/config";

export const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://mykarami.com";

interface BuildMetadataArgs {
  locale: Locale;
  path: string; // path without locale prefix, e.g. "" | "/about" | "/contact"
  title: string;
  description: string;
}

export function buildMetadata({ locale, path, title, description }: BuildMetadataArgs): Metadata {
  const url = `${siteUrl}/${locale}${path}`;

  const languages = Object.fromEntries(locales.map((l) => [l, `${siteUrl}/${l}${path}`]));

  return {
    title,
    description,
    alternates: {
      canonical: url,
      languages,
    },
    openGraph: {
      title,
      description,
      url,
      siteName: "MYK Platform",
      locale,
      type: "website",
      images: [{ url: `${siteUrl}/og-image.png`, width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [`${siteUrl}/og-image.png`],
    },
  };
}
