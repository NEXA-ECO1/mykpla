import { z } from "zod";

export const contactFormSchema = z.object({
  name: z.string().trim().min(1).max(120),
  email: z.string().trim().email().max(200),
  subject: z.string().trim().min(1).max(160),
  message: z.string().trim().min(10).max(5000),
  locale: z.string().min(2).max(5).default("en"),
  // Honeypot field — real users never fill this in; bots often do.
  company: z.string().max(0).optional(),
});

export type ContactFormInput = z.infer<typeof contactFormSchema>;
