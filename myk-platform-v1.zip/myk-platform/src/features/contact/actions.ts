"use server";

import { contactFormSchema } from "./schema";
import { contactMessageRepository } from "@/database/repositories/contact-message.repository";
import type { ContactFormState } from "@/types";

export async function submitContactForm(
  _prevState: ContactFormState,
  formData: FormData
): Promise<ContactFormState> {
  const raw = {
    name: formData.get("name")?.toString() ?? "",
    email: formData.get("email")?.toString() ?? "",
    subject: formData.get("subject")?.toString() ?? "",
    message: formData.get("message")?.toString() ?? "",
    locale: formData.get("locale")?.toString() ?? "en",
    company: formData.get("company")?.toString() ?? "",
  };

  const parsed = contactFormSchema.safeParse(raw);

  if (!parsed.success) {
    const fieldErrors: ContactFormState["fieldErrors"] = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path[0];
      if (key === "name" || key === "email" || key === "subject" || key === "message") {
        fieldErrors[key] = issue.message;
      }
    }
    return { status: "error", fieldErrors, message: "validation_error" };
  }

  // Honeypot tripped — silently pretend success so bots don't learn.
  if (parsed.data.company) {
    return { status: "success" };
  }

  try {
    await contactMessageRepository.create({
      name: parsed.data.name,
      email: parsed.data.email,
      subject: parsed.data.subject,
      message: parsed.data.message,
      locale: parsed.data.locale,
    });
    return { status: "success" };
  } catch (error) {
    console.error("[contact] failed to store message:", error);
    return { status: "error", message: "server_error" };
  }
}
