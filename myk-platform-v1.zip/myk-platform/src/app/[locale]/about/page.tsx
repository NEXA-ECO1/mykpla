import type { Metadata } from "next";
import { isLocale, defaultLocale, type Locale } from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/get-dictionary";
import { buildMetadata } from "@/lib/metadata";
import { AboutHero } from "@/components/about/hero";
import { Biography } from "@/components/about/biography";
import { AboutSkills } from "@/components/about/skills";

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);
  return buildMetadata({
    locale,
    path: "/about",
    title: dict.about.hero.title,
    description: dict.about.biography.body,
  });
}

export default async function AboutPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);

  return (
    <>
      <AboutHero dict={dict.about} />
      <Biography dict={dict.about} />
      <AboutSkills dict={dict.about} />
    </>
  );
}
