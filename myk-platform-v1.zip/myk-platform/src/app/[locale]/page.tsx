import type { Metadata } from "next";
import { isLocale, defaultLocale, type Locale } from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/get-dictionary";
import { buildMetadata, siteUrl } from "@/lib/metadata";
import { Hero } from "@/components/home/hero";
import { Intro } from "@/components/home/intro";
import { SkillsPreview } from "@/components/home/skills-preview";
import { Vision } from "@/components/home/vision";
import { Cta } from "@/components/home/cta";

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);
  return buildMetadata({
    locale,
    path: "",
    title: `${dict.common.brand.owner} — ${dict.home.hero.headline}`,
    description: dict.home.hero.subline,
  });
}

export default async function HomePage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: dict.common.brand.owner,
    url: `${siteUrl}/${locale}`,
    jobTitle: dict.home.hero.roles,
    description: dict.home.hero.subline,
    sameAs: [],
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Hero locale={locale} dict={dict.home} common={dict.common} />
      <Intro dict={dict.home} />
      <SkillsPreview dict={dict.home} />
      <Vision dict={dict.home} />
      <Cta locale={locale} dict={dict.home} />
    </>
  );
}
