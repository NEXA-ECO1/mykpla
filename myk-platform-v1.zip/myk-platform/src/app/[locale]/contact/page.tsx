import type { Metadata } from "next";
import { isLocale, defaultLocale, type Locale } from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/get-dictionary";
import { buildMetadata } from "@/lib/metadata";
import { ContactHero } from "@/components/contact/contact-hero";
import { ContactForm } from "@/components/contact/contact-form";
import { Container } from "@/components/ui/container";

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);
  return buildMetadata({
    locale,
    path: "/contact",
    title: dict.contact.hero.title,
    description: dict.contact.hero.subtitle,
  });
}

export default async function ContactPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);

  return (
    <>
      <ContactHero dict={dict.contact} />
      <section className="py-16 sm:py-20">
        <Container className="max-w-2xl">
          <ContactForm locale={locale} dict={dict.contact} />
        </Container>
      </section>
    </>
  );
}
