import type { ReactNode } from "react";
import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import { locales, isLocale, getDirection, defaultLocale, type Locale } from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/get-dictionary";
import { ThemeProvider } from "@/components/layout/theme-provider";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { siteUrl } from "@/lib/metadata";
import "../globals.css";

const display = Space_Grotesk({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "MYK — Mohammad Yasin Karami",
    template: "%s · MYK",
  },
  description: "Building tomorrow with artificial intelligence.",
  manifest: "/manifest.json",
  icons: {
    icon: "/icons/icon.svg",
    apple: "/icons/apple-touch-icon.png",
  },
};

export default async function LocaleLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: { locale: string };
}) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = await getDictionary(locale);
  const dir = getDirection(locale);

  return (
    <html lang={locale} dir={dir} className={`${display.variable} ${body.variable} ${mono.variable}`} suppressHydrationWarning>
      <body className="min-h-screen bg-void text-ink">
        <ThemeProvider>
          <a
            href="#main-content"
            className="fixed left-2 top-2 z-[100] -translate-y-16 rounded-md bg-signal px-4 py-2 text-sm text-white transition-transform focus:translate-y-0"
          >
            Skip to content
          </a>
          <Navbar locale={locale} dict={dict.common} />
          <main id="main-content">{children}</main>
          <Footer locale={locale} dict={dict.common} />
        </ThemeProvider>
      </body>
    </html>
  );
}
