import { NextRequest, NextResponse } from "next/server";
import { contactFormSchema } from "@/features/contact/schema";
import { contactMessageRepository } from "@/database/repositories/contact-message.repository";

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = contactFormSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Validation failed.", issues: parsed.error.flatten() }, { status: 422 });
  }

  if (parsed.data.company) {
    // Honeypot tripped — respond success without writing anything.
    return NextResponse.json({ ok: true }, { status: 201 });
  }

  try {
    const created = await contactMessageRepository.create({
      name: parsed.data.name,
      email: parsed.data.email,
      subject: parsed.data.subject,
      message: parsed.data.message,
      locale: parsed.data.locale,
    });
    return NextResponse.json({ ok: true, id: created.id }, { status: 201 });
  } catch (error) {
    console.error("[api/contact] failed to store message:", error);
    return NextResponse.json({ error: "Server error." }, { status: 500 });
  }
}
