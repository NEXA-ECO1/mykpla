"use client";

import { usePathname, useRouter } from "next/navigation";
import { useState, useRef, useEffect } from "react";
import { Globe } from "lucide-react";
import { locales, localeMeta, type Locale } from "@/lib/i18n/config";
import { cn } from "@/lib/utils";

export function LocaleSwitcher({ current, label }: { current: Locale; label: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function switchTo(locale: Locale) {
    const segments = pathname.split("/");
    segments[1] = locale;
    document.cookie = `MYK_LOCALE=${locale};path=/;max-age=31536000`;
    router.push(segments.join("/") || "/");
    setOpen(false);
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label={label}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="flex h-9 items-center gap-1.5 rounded-full px-3 text-sm text-ink-muted transition-colors hover:bg-white/[0.06] hover:text-ink"
      >
        <Globe size={15} />
        <span className="font-mono text-xs uppercase">{current}</span>
      </button>
      {open && (
        <div className="glass absolute end-0 top-11 z-50 min-w-[140px] rounded-xl p-1.5 shadow-2xl">
          {locales.map((locale) => (
            <button
              key={locale}
              type="button"
              onClick={() => switchTo(locale)}
              className={cn(
                "flex w-full items-center justify-between rounded-lg px-3 py-2 text-start text-sm transition-colors hover:bg-white/[0.06]",
                locale === current ? "text-ink" : "text-ink-muted"
              )}
            >
              {localeMeta[locale].nativeLabel}
              {locale === current && <span className="h-1.5 w-1.5 rounded-full bg-signal" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
