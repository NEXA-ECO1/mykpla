"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import type { Locale } from "@/lib/i18n/config";
import type { Dictionary } from "@/lib/i18n/get-dictionary";
import { Container } from "@/components/ui/container";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { LocaleSwitcher } from "@/components/layout/locale-switcher";
import { Button } from "@/components/ui/button";

export function Navbar({ locale, dict }: { locale: Locale; dict: Dictionary["common"] }) {
  const [open, setOpen] = useState(false);
  const links = [
    { href: `/${locale}`, label: dict.nav.home },
    { href: `/${locale}/about`, label: dict.nav.about },
    { href: `/${locale}/contact`, label: dict.nav.contact },
  ];

  return (
    <header className="glass-nav sticky top-0 z-50">
      <Container className="flex h-16 items-center justify-between">
        <Link href={`/${locale}`} className="flex items-center gap-2 font-display text-lg font-semibold tracking-tight">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-signal text-[13px] font-bold text-white">
            M
          </span>
          {dict.brand.name}
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-full px-4 py-2 text-sm text-ink-muted transition-colors hover:bg-white/[0.06] hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-1 md:flex">
          <LocaleSwitcher current={locale} label={dict.language.label} />
          <ThemeToggle label={dict.theme.toggle} />
          <Button asChild size="sm" className="ms-1">
            <Link href={`/${locale}/contact`}>{dict.actions.contactMe}</Link>
          </Button>
        </div>

        <button
          type="button"
          className="flex h-9 w-9 items-center justify-center rounded-full text-ink md:hidden"
          aria-label="Menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </Container>

      {open && (
        <div className="border-t border-line md:hidden">
          <Container className="flex flex-col gap-1 py-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm text-ink-muted hover:bg-white/[0.06] hover:text-ink"
              >
                {link.label}
              </Link>
            ))}
            <div className="mt-2 flex items-center justify-between px-3">
              <LocaleSwitcher current={locale} label={dict.language.label} />
              <ThemeToggle label={dict.theme.toggle} />
            </div>
          </Container>
        </div>
      )}
    </header>
  );
}
