import Link from "next/link";
import type { Locale } from "@/lib/i18n/config";
import type { Dictionary } from "@/lib/i18n/get-dictionary";
import { Container } from "@/components/ui/container";

export function Footer({ locale, dict }: { locale: Locale; dict: Dictionary["common"] }) {
  const year = new Date().getFullYear();
  return (
    <footer className="hairline border-t">
      <Container className="flex flex-col items-center gap-4 py-10 text-center sm:flex-row sm:justify-between sm:text-start">
        <div>
          <p className="font-display text-sm font-semibold text-ink">{dict.brand.name}</p>
          <p className="mt-1 text-xs text-ink-muted">{dict.footer.tagline}</p>
        </div>
        <nav className="flex gap-5 text-xs text-ink-muted">
          <Link href={`/${locale}`} className="hover:text-ink">
            {dict.nav.home}
          </Link>
          <Link href={`/${locale}/about`} className="hover:text-ink">
            {dict.nav.about}
          </Link>
          <Link href={`/${locale}/contact`} className="hover:text-ink">
            {dict.nav.contact}
          </Link>
        </nav>
        <p className="font-mono text-[11px] text-ink-faint">
          © {year} {dict.brand.owner} · {dict.footer.rights}
        </p>
      </Container>
    </footer>
  );
}
