"use client";

import { useFormState, useFormStatus } from "react-dom";
import { CheckCircle2, AlertCircle } from "lucide-react";
import { submitContactForm } from "@/features/contact/actions";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GlassCard } from "@/components/ui/glass-card";
import type { Locale } from "@/lib/i18n/config";
import type { Dictionary } from "@/lib/i18n/get-dictionary";
import type { ContactFormState } from "@/types";

const initialState: ContactFormState = { status: "idle" };

function SubmitButton({ idleLabel, pendingLabel }: { idleLabel: string; pendingLabel: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" disabled={pending} className="w-full sm:w-auto">
      {pending ? pendingLabel : idleLabel}
    </Button>
  );
}

export function ContactForm({ locale, dict }: { locale: Locale; dict: Dictionary["contact"] }) {
  const [state, formAction] = useFormState(submitContactForm, initialState);

  return (
    <GlassCard className="p-6 sm:p-10">
      {state.status === "success" ? (
        <div className="flex flex-col items-center gap-3 py-10 text-center">
          <CheckCircle2 className="text-signal-soft" size={32} />
          <p className="max-w-sm text-ink">{dict.status.success}</p>
        </div>
      ) : (
        <form action={formAction} className="space-y-5" noValidate>
          <input type="hidden" name="locale" value={locale} />
          {/* Honeypot — hidden from real users, visible to naive bots */}
          <input
            type="text"
            name="company"
            tabIndex={-1}
            autoComplete="off"
            className="absolute left-[-9999px] h-0 w-0 opacity-0"
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <Label htmlFor="name">{dict.form.name}</Label>
              <Input id="name" name="name" placeholder={dict.form.namePlaceholder} required maxLength={120} />
              {state.fieldErrors?.name && <p className="mt-1.5 text-xs text-ember">{state.fieldErrors.name}</p>}
            </div>
            <div>
              <Label htmlFor="email">{dict.form.email}</Label>
              <Input id="email" name="email" type="email" placeholder={dict.form.emailPlaceholder} required maxLength={200} />
              {state.fieldErrors?.email && <p className="mt-1.5 text-xs text-ember">{state.fieldErrors.email}</p>}
            </div>
          </div>

          <div>
            <Label htmlFor="subject">{dict.form.subject}</Label>
            <Input id="subject" name="subject" placeholder={dict.form.subjectPlaceholder} required maxLength={160} />
            {state.fieldErrors?.subject && <p className="mt-1.5 text-xs text-ember">{state.fieldErrors.subject}</p>}
          </div>

          <div>
            <Label htmlFor="message">{dict.form.message}</Label>
            <Textarea id="message" name="message" rows={6} placeholder={dict.form.messagePlaceholder} required minLength={10} maxLength={5000} />
            {state.fieldErrors?.message && <p className="mt-1.5 text-xs text-ember">{state.fieldErrors.message}</p>}
          </div>

          {state.status === "error" && !state.fieldErrors && (
            <div className="flex items-center gap-2 rounded-xl border border-ember/30 bg-ember/10 px-4 py-3 text-sm text-ember-soft">
              <AlertCircle size={16} />
              {dict.status.error}
            </div>
          )}

          <SubmitButton idleLabel={dict.form.submit} pendingLabel={dict.form.submitting} />
        </form>
      )}
    </GlassCard>
  );
}
