import { Container } from "@/components/ui/container";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function ContactHero({ dict }: { dict: Dictionary["contact"] }) {
  return (
    <section className="hairline relative overflow-hidden border-b py-16 text-center sm:py-24">
      <div className="pointer-events-none absolute inset-0 bg-grid-fade opacity-70" aria-hidden />
      <Container className="relative">
        <p className="eyebrow">{dict.hero.eyebrow}</p>
        <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight text-gradient sm:text-5xl">
          {dict.hero.title}
        </h1>
        <p className="mx-auto mt-4 max-w-md text-balance text-ink-muted">{dict.hero.subtitle}</p>
      </Container>
    </section>
  );
}
