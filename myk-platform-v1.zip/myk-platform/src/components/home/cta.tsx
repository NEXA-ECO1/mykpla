import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Container } from "@/components/ui/container";
import { Button } from "@/components/ui/button";
import type { Locale } from "@/lib/i18n/config";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function Cta({ locale, dict }: { locale: Locale; dict: Dictionary["home"] }) {
  return (
    <section className="hairline border-t py-20 sm:py-28">
      <Container>
        <div className="glass relative overflow-hidden rounded-3xl px-8 py-16 text-center sm:px-16">
          <div className="pointer-events-none absolute inset-0 bg-grid-fade opacity-60" aria-hidden />
          <h2 className="relative text-balance font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            {dict.cta.title}
          </h2>
          <p className="relative mx-auto mt-4 max-w-md text-balance text-ink-muted">{dict.cta.body}</p>
          <Button asChild size="lg" className="relative mt-8">
            <Link href={`/${locale}/contact`}>
              {dict.cta.button}
              <ArrowUpRight size={16} />
            </Link>
          </Button>
        </div>
      </Container>
    </section>
  );
}
