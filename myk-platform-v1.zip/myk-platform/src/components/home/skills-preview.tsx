import { Container } from "@/components/ui/container";
import { GlassCard } from "@/components/ui/glass-card";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function SkillsPreview({ dict }: { dict: Dictionary["home"] }) {
  return (
    <section className="hairline border-t py-20 sm:py-28">
      <Container>
        <p className="eyebrow">02 · Toolkit</p>
        <h2 className="mt-4 max-w-xl font-display text-2xl font-semibold tracking-tight sm:text-3xl">
          {dict.skills.title}
        </h2>
        <p className="mt-3 max-w-xl text-ink-muted">{dict.skills.subtitle}</p>

        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {dict.skills.items.map((item) => (
            <GlassCard key={item.name} className="p-6 transition-colors hover:bg-white/[0.06]">
              <p className="font-display text-lg font-medium">{item.name}</p>
              <p className="mt-1.5 text-sm text-ink-muted">{item.detail}</p>
            </GlassCard>
          ))}
        </div>
      </Container>
    </section>
  );
}
