import { Check } from "lucide-react";
import { Container } from "@/components/ui/container";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function Vision({ dict }: { dict: Dictionary["home"] }) {
  return (
    <section id="vision" className="hairline border-t py-20 sm:py-28">
      <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        <div>
          <p className="eyebrow">03 · {dict.vision.eyebrow}</p>
          <h2 className="mt-4 max-w-lg text-balance font-display text-2xl font-semibold tracking-tight sm:text-3xl">
            {dict.vision.title}
          </h2>
          <p className="mt-5 max-w-lg text-balance leading-relaxed text-ink-muted">{dict.vision.body}</p>
        </div>

        <div className="glass rounded-2xl p-2">
          <ul className="divide-y divide-line">
            {dict.vision.points.map((point) => (
              <li key={point} className="flex items-center gap-3 px-4 py-4">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-signal/15 text-signal-soft">
                  <Check size={13} />
                </span>
                <span className="text-sm text-ink">{point}</span>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </section>
  );
}
