import { Container } from "@/components/ui/container";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function Intro({ dict }: { dict: Dictionary["home"] }) {
  return (
    <section className="hairline border-t py-20 sm:py-28">
      <Container className="max-w-3xl">
        <p className="eyebrow">01 · Intro</p>
        <h2 className="mt-4 font-display text-2xl font-semibold tracking-tight sm:text-3xl">{dict.intro.title}</h2>
        <p className="mt-5 text-balance text-base leading-relaxed text-ink-muted sm:text-lg">{dict.intro.body}</p>
      </Container>
    </section>
  );
}
