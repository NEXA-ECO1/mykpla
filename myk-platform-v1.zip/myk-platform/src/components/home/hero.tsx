"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { HeroMonogram } from "./hero-monogram";
import { Button } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import type { Locale } from "@/lib/i18n/config";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function Hero({ locale, dict, common }: { locale: Locale; dict: Dictionary["home"]; common: Dictionary["common"] }) {
  const roles = dict.hero.roles;
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % roles.length), 2600);
    return () => clearInterval(id);
  }, [roles.length]);

  const currentRole = roles[index] ?? roles[0] ?? "";

  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 bg-grid-fade" aria-hidden />
      <div
        className="pointer-events-none absolute -top-24 start-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-signal/20 blur-[120px] animate-pulse-glow"
        aria-hidden
      />

      <Container className="relative flex flex-col items-center pb-24 pt-20 text-center sm:pt-28">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-10 animate-drift"
        >
          <HeroMonogram />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="eyebrow"
        >
          {dict.hero.eyebrow}
        </motion.p>

        <div className="mt-4 h-7 font-mono text-sm text-ink-muted" aria-live="polite">
          <AnimatePresence mode="wait">
            <motion.span
              key={currentRole}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.35 }}
            >
              {currentRole}
            </motion.span>
          </AnimatePresence>
        </div>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.35 }}
          className="mt-6 max-w-3xl text-balance font-display text-4xl font-semibold leading-[1.1] tracking-tight text-gradient sm:text-6xl"
        >
          {dict.hero.headline}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-6 max-w-xl text-balance text-base text-ink-muted sm:text-lg"
        >
          {dict.hero.subline}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.65 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <Button asChild size="lg">
            <Link href={`/${locale}#vision`}>
              {common.actions.viewProjects}
              <ArrowUpRight size={16} />
            </Link>
          </Button>
          <Button asChild variant="glass" size="lg">
            <Link href={`/${locale}/contact`}>{common.actions.contactMe}</Link>
          </Button>
        </motion.div>
      </Container>
    </section>
  );
}
