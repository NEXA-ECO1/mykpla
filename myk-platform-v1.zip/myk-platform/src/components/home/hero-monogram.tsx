"use client";

import { motion } from "framer-motion";

// Node coordinates trace the letterforms M · Y · K as a connected graph —
// echoing the neural-network aesthetic of the work itself rather than
// using a static logotype.
const nodes = [
  // M
  { id: "m1", x: 20, y: 180 },
  { id: "m2", x: 20, y: 20 },
  { id: "m3", x: 60, y: 100 },
  { id: "m4", x: 100, y: 20 },
  { id: "m5", x: 100, y: 180 },
  // Y
  { id: "y1", x: 140, y: 20 },
  { id: "y2", x: 170, y: 90 },
  { id: "y3", x: 200, y: 20 },
  { id: "y4", x: 170, y: 180 },
  // K
  { id: "k1", x: 230, y: 20 },
  { id: "k2", x: 230, y: 100 },
  { id: "k3", x: 230, y: 180 },
  { id: "k4", x: 272, y: 20 },
  { id: "k5", x: 272, y: 180 },
];

const edges: [string, string][] = [
  ["m1", "m2"],
  ["m2", "m3"],
  ["m3", "m4"],
  ["m4", "m5"],
  ["y1", "y2"],
  ["y3", "y2"],
  ["y2", "y4"],
  ["k1", "k2"],
  ["k2", "k3"],
  ["k2", "k4"],
  ["k2", "k5"],
];

function findNode(id: string) {
  return nodes.find((n) => n.id === id)!;
}

export function HeroMonogram() {
  return (
    <svg
      viewBox="0 0 292 200"
      className="h-auto w-full max-w-md"
      role="img"
      aria-label="MYK monogram, rendered as a connected node graph"
    >
      <defs>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3.2" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {edges.map(([a, b], i) => {
        const from = findNode(a);
        const to = findNode(b);
        return (
          <motion.line
            key={`${a}-${b}`}
            x1={from.x}
            y1={from.y}
            x2={to.x}
            y2={to.y}
            stroke="#5B4CFF"
            strokeWidth={1.5}
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.7 }}
            transition={{ duration: 0.9, delay: 0.3 + i * 0.07, ease: [0.16, 1, 0.3, 1] }}
          />
        );
      })}

      {nodes.map((node, i) => (
        <motion.circle
          key={node.id}
          cx={node.x}
          cy={node.y}
          r={4}
          fill="#F2F2F7"
          filter="url(#glow)"
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.15 + i * 0.045, ease: "easeOut" }}
        />
      ))}
    </svg>
  );
}
