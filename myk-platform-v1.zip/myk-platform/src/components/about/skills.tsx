import { Container } from "@/components/ui/container";
import { GlassCard } from "@/components/ui/glass-card";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function AboutSkills({ dict }: { dict: Dictionary["about"] }) {
  return (
    <section className="hairline border-t py-16 sm:py-20">
      <Container className="max-w-3xl">
        <h2 className="font-display text-2xl font-semibold tracking-tight">{dict.skills.title}</h2>
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {dict.skills.categories.map((category) => (
            <GlassCard key={category.label} className="p-5">
              <p className="text-sm font-medium text-ink">{category.label}</p>
              <ul className="mt-3 flex flex-wrap gap-1.5">
                {category.items.map((item) => (
                  <li
                    key={item}
                    className="rounded-full border border-line bg-white/[0.03] px-2.5 py-1 font-mono text-[11px] text-ink-muted"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </GlassCard>
          ))}
        </div>
      </Container>
    </section>
  );
}
