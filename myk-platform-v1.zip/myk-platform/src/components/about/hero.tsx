import { Container } from "@/components/ui/container";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

export function AboutHero({ dict }: { dict: Dictionary["about"] }) {
  return (
    <section className="hairline relative overflow-hidden border-b py-20 text-center sm:py-28">
      <div className="pointer-events-none absolute inset-0 bg-grid-fade opacity-70" aria-hidden />
      <Container className="relative">
        <p className="eyebrow">{dict.hero.eyebrow}</p>
        <h1 className="mt-4 text-balance font-display text-4xl font-semibold tracking-tight text-gradient sm:text-5xl">
          {dict.hero.title}
        </h1>
      </Container>
    </section>
  );
}
