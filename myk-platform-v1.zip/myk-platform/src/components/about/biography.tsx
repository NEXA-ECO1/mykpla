import { Container } from "@/components/ui/container";
import type { Dictionary } from "@/lib/i18n/get-dictionary";

function Block({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="grid grid-cols-1 gap-4 py-10 sm:grid-cols-[100px_1fr] sm:gap-8">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-ink-faint">{index}</p>
      <div>
        <h2 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">{title}</h2>
        <p className="mt-3 max-w-2xl text-balance leading-relaxed text-ink-muted">{body}</p>
      </div>
    </div>
  );
}

export function Biography({ dict }: { dict: Dictionary["about"] }) {
  const blocks = [
    { index: "01", title: dict.biography.title, body: dict.biography.body },
    { index: "02", title: dict.story.title, body: dict.story.body },
    { index: "03", title: dict.journey.title, body: dict.journey.body },
    { index: "04", title: dict.interests.title, body: dict.interests.body },
    { index: "05", title: dict.vision.title, body: dict.vision.body },
  ];

  return (
    <section className="py-4">
      <Container className="max-w-3xl divide-y divide-line">
        {blocks.map((b) => (
          <Block key={b.index} {...b} />
        ))}
      </Container>
    </section>
  );
}
