import { prisma } from "@/lib/prisma";
import type { ContactMessage } from "@prisma/client";

export interface CreateContactMessageInput {
  name: string;
  email: string;
  subject: string;
  message: string;
  locale: string;
}

/**
 * All access to the ContactMessage table goes through this repository.
 * Nothing outside src/database/ should import PrismaClient directly —
 * that keeps a future ORM or provider swap (e.g. SQLite -> Postgres,
 * or Prisma -> Drizzle) to a single file.
 */
export const contactMessageRepository = {
  create(input: CreateContactMessageInput): Promise<ContactMessage> {
    return prisma.contactMessage.create({ data: input });
  },

  findMany(): Promise<ContactMessage[]> {
    return prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" } });
  },
};
